from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
import os, re, time, threading, ipaddress, requests
from typing import List, Dict, Any, Optional
from qdrant_client import QdrantClient
from qdrant_client.http.models import Filter, FieldCondition, MatchValue
from sentence_transformers import SentenceTransformer
from rapidfuzz import fuzz
from neo4j import GraphDatabase

QDRANT_URL = os.environ.get("QDRANT_URL","http://qdrant:6333")
QDRANT_COLLECTION = os.environ.get("QDRANT_COLLECTION","pmoves_chunks")
SENTENCE_MODEL = os.environ.get("SENTENCE_MODEL","all-MiniLM-L6-v2")
USE_OLLAMA_EMBED = os.environ.get("USE_OLLAMA_EMBED","false").lower()=="true"
OLLAMA_URL = os.environ.get("OLLAMA_URL","http://ollama:11434")
HTTP_PORT = int(os.environ.get("HIRAG_HTTP_PORT","8086"))
NEO4J_URL = os.environ.get("NEO4J_URL","bolt://neo4j:7687")
NEO4J_USER = os.environ.get("NEO4J_USER","neo4j")
NEO4J_PASSWORD = os.environ.get("NEO4J_PASSWORD","neo4j")
GRAPH_BOOST = float(os.environ.get("GRAPH_BOOST","0.15"))
ENTITY_CACHE_TTL = int(os.environ.get("ENTITY_CACHE_TTL","60"))
ENTITY_CACHE_MAX = int(os.environ.get("ENTITY_CACHE_MAX","1000"))
NEO4J_DICT_REFRESH_SEC = int(os.environ.get("NEO4J_DICT_REFRESH_SEC","60"))
NEO4J_DICT_LIMIT = int(os.environ.get("NEO4J_DICT_LIMIT","50000"))
USE_MEILI = os.environ.get("USE_MEILI","false").lower()=="true"
MEILI_URL = os.environ.get("MEILI_URL","http://meilisearch:7700")
MEILI_API_KEY = os.environ.get("MEILI_API_KEY","master_key")
TAILSCALE_ONLY = os.environ.get("TAILSCALE_ONLY","true").lower()=="true"
TAILSCALE_ADMIN_ONLY = os.environ.get("TAILSCALE_ADMIN_ONLY","true").lower()=="true"
TAILSCALE_CIDRS = [c.strip() for c in os.environ.get("TAILSCALE_CIDRS","100.64.0.0/10").split(",") if c.strip()]

app = FastAPI(title="PMOVES Hi‑RAG Gateway")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

qdrant = QdrantClient(url=QDRANT_URL, timeout=20.0)
driver = GraphDatabase.driver(NEO4J_URL, auth=(NEO4J_USER, NEO4J_PASSWORD))

_model = None
def embed_query(text: str):
    global _model
    if USE_OLLAMA_EMBED:
        r = requests.post(f"{OLLAMA_URL}/api/embeddings", json={"model":"nomic-embed-text","prompt":text}, timeout=30)
        if not r.ok:
            raise HTTPException(502, f"Ollama embed error: {r.text[:160]}")
        return r.json().get("embedding")
    if _model is None:
        _model = SentenceTransformer(SENTENCE_MODEL)
    return _model.encode([text], normalize_embeddings=True).tolist()[0]

def hybrid_score(vec_score: float, lex_score: float, alpha: float=0.7) -> float:
    return alpha*vec_score + (1.0-alpha)*lex_score

_warm_entities = {}
_warm_last = 0.0
def refresh_warm_dictionary():
    global _warm_entities, _warm_last
    try:
        tmp = {}
        with driver.session() as s:
            recs = s.run("MATCH (e:Entity) RETURN e.value AS v, coalesce(e.type,'UNK') AS t LIMIT $lim",
                         lim=NEO4J_DICT_LIMIT)
            for r in recs:
                v = r["v"]; t = (r["t"] or "UNK").upper()
                if not v: continue
                tmp.setdefault(t, set()).add(v)
        _warm_entities = tmp
        _warm_last = time.time()
    except Exception as e:
        print("warm dictionary error:", e)

def warm_loop():
    while True:
        try: refresh_warm_dictionary()
        except Exception as e: print("warm loop error:", e)
        time.sleep(max(15, NEO4J_DICT_REFRESH_SEC))
threading.Thread(target=warm_loop, daemon=True).start()

def graph_terms(query: str, limit: int = 8, entity_types: Optional[List[str]]=None):
    toks = [t.lower() for t in re.split(r"\\W+", query) if t and len(t) > 2]
    if not toks: return []
    types_norm = set([x.upper() for x in (entity_types or [])]) if entity_types else None
    out = set()
    for tname, values in _warm_entities.items():
        if types_norm and tname not in types_norm: continue
        for val in values:
            lv = val.lower()
            if any(tok in lv for tok in toks):
                out.add(val)
                if len(out) >= limit: return list(out)[:limit]
    return list(out)[:limit]

def meili_lexical(query, namespace, limit):
    if not USE_MEILI: return {}
    try:
        headers={'Authorization': f'Bearer {MEILI_API_KEY}'} if MEILI_API_KEY else {}
        payload={'q': query, 'limit': max(10, limit*3), 'filter': [f"namespace = '{namespace}'"]}
        r = requests.post(f"{MEILI_URL}/indexes/pmoves_chunks/search", json=payload, headers=headers, timeout=10)
        if not r.ok: return {}
        hits = r.json().get('hits', [])
        out = {}
        for i, h in enumerate(hits):
            cid = h.get('chunk_id') or h.get('id')
            if not cid: continue
            score = h.get('_rankingScore') or (1.0 - i/max(1.0, len(hits)))
            out[cid] = float(score)
        return out
    except Exception:
        return {}

def run_query(query, namespace, k=8, alpha=0.7, graph_boost=0.15, entity_types=None):
    from qdrant_client.http.models import Filter, FieldCondition, MatchValue
    emb = embed_query(query)
    cond = Filter(must=[FieldCondition(key="namespace", match=MatchValue(value=namespace))])
    sr = qdrant.search(QDRANT_COLLECTION, query_vector=emb, limit=max(16,k), query_filter=cond, with_payload=True, with_vectors=False)
    gterms = set([t.lower() for t in graph_terms(query, entity_types=entity_types)])
    meili_scores = meili_lexical(query, namespace, k) if USE_MEILI else {}
    results = []
    for p in sr:
        txt = p.payload.get("text","")
        lex = float(meili_scores.get(p.payload.get('chunk_id'), 0.0)) if USE_MEILI else (fuzz.token_set_ratio(query, txt)/100.0)
        vec = float(p.score) if isinstance(p.score, (int,float)) else 0.0
        g_hit = any(term in txt.lower() for term in gterms)
        score = hybrid_score(vec, lex, alpha) + (graph_boost if g_hit else 0.0)
        results.append({
            "doc_id": p.payload.get("doc_id"),
            "section_id": p.payload.get("section_id"),
            "chunk_id": p.payload.get("chunk_id"),
            "text": txt,
            "score": score,
            "namespace": p.payload.get("namespace"),
            "graph_match": bool(g_hit)
        })
    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:k]

def _client_ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for")
    if xff: return xff.split(",")[0].strip()
    return request.client.host if request.client else "127.0.0.1"

def _ip_in_cidrs(ip: str, cidrs):
    try:
        ip_obj = ipaddress.ip_address(ip)
        for c in cidrs:
            try:
                if ip_obj in ipaddress.ip_network(c): return True
            except Exception: continue
    except Exception: return False
    return False

def require_tailscale(request: Request):
    if not TAILSCALE_ONLY: return
    ip = _client_ip(request)
    if not _ip_in_cidrs(ip, TAILSCALE_CIDRS):
        raise HTTPException(status_code=403, detail="Admin restricted to Tailscale network")

@app.post("/hirag/query")
def http_query(body: dict):
    q = body.get("query","")
    ns = body.get("namespace","default")
    k = int(body.get("k",8))
    alpha = float(body.get("alpha",0.7))
    gb = float(body.get("graph_boost", GRAPH_BOOST))
    et = body.get("entity_types")
    return {"query": q, "results": run_query(q, ns, k, alpha, gb, et)}

@app.get("/hirag/admin/stats")
def hirag_admin_stats(_=Depends(require_tailscale)):
    return {
        "warm_dictionary": {"types": len(_warm_entities), "entries": int(sum(len(s) for s in _warm_entities.values())), "last_refresh": _warm_last},
        "config": {"USE_MEILI": USE_MEILI, "GRAPH_BOOST": GRAPH_BOOST, "NEO4J_DICT_REFRESH_SEC": NEO4J_DICT_REFRESH_SEC, "NEO4J_DICT_LIMIT": NEO4J_DICT_LIMIT, "USE_OLLAMA_EMBED": USE_OLLAMA_EMBED}
    }

@app.post("/hirag/admin/refresh")
def hirag_admin_refresh(_=Depends(require_tailscale)):
    refresh_warm_dictionary()
    return {"ok": True, "entries": int(sum(len(s) for s in _warm_entities.values()))}

@app.get("/")
def index():
    return {"ok": True, "hint": "POST /hirag/query"}
