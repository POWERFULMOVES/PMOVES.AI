# PR: Hi‑RAG hybrid + Retrieval‑Eval sweeps
